        <div id="slider" class="nivoSlider">
                        <img src="admin/images/1.JPG" data-thumb="images/1.jpg" alt="" />
                        <img src="admin/images/2.JPG" data-thumb="images/toystory.jpg" alt="" />
                        <img src="admin/images/3.JPG" data-thumb="images/wineries.jpg" alt="" t />
                        <img src="admin/images/4.JPG"  alt="" data-transition="slideInLeft" />
                   
                    </div>
