<?php
$conn = mysqli_connect('localhost','root','','elearning')or die(mysqli_error());
?>
