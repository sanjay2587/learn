<br>
<div class="navbar  navbar-inverse">
    <div class="navbar-inner">
        <div class="footerindex">
            <center><img width="25" height="25" src="admin/img/chmsc.PNG">&nbsp;E-Learning System Developed by:Sanjay</center>
        </div>
        <!-- modal -->
        <!-- mission -->
        <div id="mission" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <div class="alert alert-info"><strong>Mission</strong></div>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quis error, eum ex veniam dolore mollitia ducimus ullam earum fugiat fugit qui repudiandae saepe dolor quibusdam voluptates commodi, unde quisquam, quos ipsam consequatur! Vitae voluptate consequuntur distinctio exercitationem error beatae id. 
                </p>

                <div class="alert alert-info"><strong>E-Learning Mission</strong></div>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Est saepe hic molestias quibusdam dolorem repudiandae praesentium nihil ipsum odit ad qui, error consectetur, numquam corporis vitae rerum ipsa laboriosam ratione.
                </p>
            </div>
            <div class="modal-footer">
                <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove-sign icon-large"></i>&nbsp;Close</button>
            </div>
        </div>
        <!-- end mission -->
        <!-- vision -->
        <div id="vision" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
            </div>
            <div class="modal-body">
                <div class="alert alert-info"><strong>Vision</strong></div>

                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod accusamus debitis corporis maiores dolorem optio eaque officiis voluptate repellat corrupti soluta, consectetur recusandae adipisci amet, obcaecati odio. Voluptatem consectetur possimus id, repudiandae eaque illo dolores ex saepe! Cumque, enim voluptate. </p>

                <div class="alert alert-info"><strong>E-Learning Vision</strong></div>
               
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae impedit laborum voluptate eligendi voluptates cum eveniet sunt nihil dicta placeat aliquid consequatur esse ut porro, vel rem quos voluptatibus ipsa.

            </div>
            <div class="modal-footer">
                <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove-sign icon-large"></i>&nbsp;Close</button>
            </div>
        </div>
        <!-- end vision -->
        <!--end modal -->

    </div>
</div>
</div>


